/* Shared ESLint config that registers @typescript-eslint plugin and parser.
   Exported as CommonJS so both CJS and ESM configs can require/import it.
*/
// Export two pieces: a base (non-TypeScript-specific) config and a TypeScript-scoped config
module.exports = {
  base: {
    rules: {
      'no-console': [
        'warn',
        {
          allow: ['warn', 'error'],
        },
      ],
      // Prettier integration - disable conflicting rules
      'max-len': 'off',
      'comma-dangle': 'off',
      'object-curly-spacing': 'off',
      quotes: 'off',
      semi: 'off',
    },
  },
  typescript: {
    // scope these rules to TS files only
    files: ['**/*.ts', '**/*.tsx', '**/*.d.ts'],
    rules: {
      '@typescript-eslint/no-explicit-any': 'off',
      // '@typescript-eslint/no-floating-promises': 'warn',
      'simple-import-sort/imports': 'error',
      'simple-import-sort/exports': 'error',
      '@typescript-eslint/no-unsafe-argument': 'warn',
      '@typescript-eslint/no-unsafe-assignment': 'warn',
      '@typescript-eslint/no-unused-vars': [
        'error',
        {
          args: 'all',
          argsIgnorePattern: '^_',
          caughtErrors: 'all',
          caughtErrorsIgnorePattern: '^_',
          destructuredArrayIgnorePattern: '^_',
          varsIgnorePattern: '^_',
          ignoreRestSiblings: true,
        },
      ],
    },
  },
};
