import { PostCreateScreen } from '~/components/post/PostCreateScreen';

export default function CreatePost() {
  return <PostCreateScreen />;
}
