/**
 * Deprecated: user-article.* loaders were duplicate many-to-one
 * lookup implementations. Use the canonical `UserLoader` and
 * `PostLoader` for user/post lookups instead.
 */

export {};
