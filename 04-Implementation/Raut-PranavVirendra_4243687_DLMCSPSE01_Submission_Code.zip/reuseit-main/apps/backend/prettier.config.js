module.exports = {
  ...require('../../.prettierrc.json'),
  // Mobile-specific overrides
  bracketSameLine: true,
  tailwindAttributes: ['className'],
};
